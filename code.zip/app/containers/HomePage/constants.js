/*
 *
 * HomePage constants
 *
 */

export const DEFAULT_ACTION = 'app/HomePage/DEFAULT_ACTION';
export const GET_TECH_CRUNCH_DATA = 'app/HomePage/GET_TECH_CRUNCH_DATA';
export const TECH_CRUNCH_DATA_SUCCESS = 'app/HomePage/TECH_CRUNCH_DATA_SUCCESS';
export const TECH_CRUNCH_DATA_FAIL = 'app/HomePage/TECH_CRUNCH_DATA_FAIL';
